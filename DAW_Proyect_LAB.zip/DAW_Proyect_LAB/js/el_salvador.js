function mapa(){
     fila="";
     fila+="<div > ";  
     fila+="<img class=Santa_Ana  onmouseover=Santa_Ana()  onmouseout=hacer2() src=img/Santa_Ana.png>";
     fila+="<img class=Ahuchapan  onmouseover=Ahuachapan() onmouseout=hacer3() src=img/Ahuchapan.png>"; 
     fila+="<img class=Sonsonate  onmouseover=Sonsonate() onmouseout=hacer4() src=img/Sonsonate.png>"; 
     fila+="<img class=Chalatenango onmouseover=Chalatenango() onmouseout=hacer5() src=img/Chalatenango.png>";  
     fila+="<img class=La_Libertad onmouseover=La_Libertad() onmouseout=hacer6() src=img/La_Libertad.png>";   
     fila+="<img class=San_Salvador onmouseover=San_Salvador() onmouseout=hacer7() src=img/San_Salvador.png>";   
     fila+="<img class=Cuscatlan onmouseover=Cuscatlan() onmouseout=hacer8() src=img/Cuscatlan.png>"; 
     fila+="<img class=Cabañas onmouseover=Cabañas() onmouseout=hacer9() src=img/Cabañas.png>";   
     fila+="<img class=La_Paz  onmouseover=La_Paz() onmouseout=hacer10() src=img/La_Paz.png>";
     fila+="<img class=Usulutan  onmouseover=Usulutan() onmouseout=hacer11() src=img/Usulutan.png>"; 
     fila+="<img class=San_Vicente onmouseover=San_Vicente() onmouseout=hacer12()  src=img/San_Vicente.png>";  
     fila+="<img class=San_Miguel onmouseover=San_Miguel() onmouseout=hacer13() src=img/San_Miguel.png>";   
     fila+="<img class=Morazan onmouseover=Morazan() onmouseout=hacer14() src=img/Morazan.png>"; 
     fila+="<img class=La_Union onmouseover=La_Union() onmouseout=hacer15() src=img/La_Union.png>"; 
     fila+="</div>";
     fila+="<div > ";
     fila+="</div>";
     document.getElementById("div1").innerHTML=fila;
     
}
function Santa_Ana(){
     fila="";
     fila+="<table>";
     fila+="<tr>";
     fila+="<td><b>Cabecera departamental</b></td>";
     fila+="<td><b>Santa Ana</b></td>";
     fila+="</tr>";
     fila+="<tr>";
     fila+="<td><b> Extencion territorial</b></td>";
     fila+="<td><b> 2,023km<sup>2</sup></b></td>";
     fila+="</tr>";
     fila+="<tr>";
     fila+="<td> <b>Fiestas patronales</b></td>";
     fila+="<td><b>Del 17 al 26 de julio</b></td>";
     fila+="</tr>";
     fila+="<tr>";
     fila+="<td><b> Habitantes</b></td>";
     fila+="<td><b>631,100 habitantes</b></td>";
     fila+="</tr>";
     fila+="</table>";
     document.getElementById("div2").innerHTML=fila;

}
function hacer2(){
     fila="";
     fila+="";
     document.getElementById("div2").innerHTML=fila;
}
function Ahuachapan(){
     fila1="";
     fila1+="<table  >";
     fila1+="<tr>";
     fila1+="<td><b>Cabecera departamental</b></td>";
     fila1+="<td><b>Ahuachapan</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Extencion territorial</b></td>";
     fila1+="<td><b>1,240km<sup>2</sup></b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td> <b>Fiestas patronales</b></td>";
     fila1+="<td><b>Del 5 al 14 de febrero</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Habitantes</b></td>";
     fila1+="<td><b>129,750 habitantes</b></td>";
     fila1+="</tr>";
     fila1+="</table>";
     document.getElementById("div3").innerHTML=fila1;

}
function hacer3(){
     fila1="";
     fila1+="";
     document.getElementById("div3").innerHTML=fila1;
}
function Sonsonate(){
     fila1="";
     fila1+="<table  >";
     fila1+="<tr>";
     fila1+="<td><b>Cabecera departamental</b></td>";
     fila1+="<td><b>Sonsonate</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Extencion territorial</b></td>";
     fila1+="<td><b>1,226km<sup>2</sup></b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td> <b>Fiestas patronales</b></td>";
     fila1+="<td><b>2 de febrero</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Habitantes</b></td>";
     fila1+="<td><b>518,522  habitantes</b></td>";
     fila1+="</tr>";
     fila1+="</table>";
     document.getElementById("div4").innerHTML=fila1;

}
function hacer4(){
     fila1="";
     fila1+="";
     document.getElementById("div4").innerHTML=fila1;
}
function Chalatenango(){
     fila1="";
     fila1+="<table  >";
     fila1+="<tr>";
     fila1+="<td><b>Cabecera departamental</b></td>";
     fila1+="<td><b>Chalatenango</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Extencion territorial</b></td>";
     fila1+="<td><b>131,05km<sup>2</sup></b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td> <b>Fiestas patronales</b></td>";
     fila1+="<td><b>Del 15 al 24 de junio</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Habitantes</b></td>";
     fila1+="<td><b>274,878  habitantes</b></td>";
     fila1+="</tr>";
     fila1+="</table>";
     document.getElementById("div5").innerHTML=fila1;

}
function hacer5(){
     fila1="";
     fila1+="";
     document.getElementById("div5").innerHTML=fila1;
}
function La_Libertad(){
     fila1="";
     fila1+="<table  >";
     fila1+="<tr>";
     fila1+="<td><b>Cabecera departamental</b></td>";
     fila1+="<td><b>Santa Tecla</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Extencion territorial</b></td>";
     fila1+="<td><b>1,653km<sup>2</sup></b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td> <b>Fiestas patronales</b></td>";
     fila1+="<td><b>Del 1 al 8 de diciembre</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Habitantes</b></td>";
     fila1+="<td><b>843,500  habitantes</b></td>";
     fila1+="</tr>";
     fila1+="</table>";
     document.getElementById("div6").innerHTML=fila1;

}
function hacer6(){
     fila1="";
     fila1+="";
     document.getElementById("div6").innerHTML=fila1;
}
function San_Salvador(){
     fila1="";
     fila1+="<table  >";
     fila1+="<tr>";
     fila1+="<td><b>Cabecera departamental</b></td>";
     fila1+="<td><b>San Salvador</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Extencion territorial</b></td>";
     fila1+="<td><b>886.2 km<sup>2</sup></b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td> <b>Fiestas patronales</b></td>";
     fila1+="<td><b>6 de agosto</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Habitantes</b></td>";
     fila1+="<td><b>2,557,761  habitantes</b></td>";
     fila1+="</tr>";
     fila1+="</table>";
     document.getElementById("div7").innerHTML=fila1;

}
function hacer7(){
     fila1="";
     fila1+="";
     document.getElementById("div7").innerHTML=fila1;
}
function Cuscatlan(){
     fila1="";
     fila1+="<table  >";
     fila1+="<tr>";
     fila1+="<td><b>Cabecera departamental</b></td>";
     fila1+="<td><b>Cojutepeque</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Extencion territorial</b></td>";
     fila1+="<td><b>756km<sup>2</sup></b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td> <b>Fiestas patronales</b></td>";
     fila1+="<td><b>15 al 29 de enero</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Habitantes</b></td>";
     fila1+="<td><b>216,446 habitantes</b></td>";
     fila1+="</tr>";
     fila1+="</table>";
     document.getElementById("div8").innerHTML=fila1;

}
function hacer8(){
     fila1="";
     fila1+="";
     document.getElementById("div8").innerHTML=fila1;
}
function Cabañas(){
     fila1="";
     fila1+="<table  >";
     fila1+="<tr>";
     fila1+="<td><b>Cabecera departamental</b></td>";
     fila1+="<td><b>Sensuntepeque</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Extencion territorial</b></td>";
     fila1+="<td><b>1,103.51 km<sup>2</sup></b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td> <b>Fiestas patronales</b></td>";
     fila1+="<td><b>Del 20 al 29 de septiembre</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Habitantes</b></td>";
     fila1+="<td><b>149,326 habitantes</b></td>";
     fila1+="</tr>";
     fila1+="</table>";
     document.getElementById("div9").innerHTML=fila1;

}
function hacer9(){
     fila1="";
     fila1+="";
     document.getElementById("div9").innerHTML=fila1;
}
function La_Paz(){
     fila1="";
     fila1+="<table  >";
     fila1+="<tr>";
     fila1+="<td><b>Cabecera departamental</b></td>";
     fila1+="<td><b>Zacatecoluca</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Extencion territorial</b></td>";
     fila1+="<td><b>1,223,61km<sup>2</sup></b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td> <b>Fiestas patronales</b></td>";
     fila1+="<td><b>Del 15 al 18 de agosto</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Habitantes</b></td>";
     fila1+="<td><b>288,022  habitantes</b></td>";
     fila1+="</tr>";
     fila1+="</table>";
     document.getElementById("div10").innerHTML=fila1;

}
function hacer10(){
     fila1="";
     fila1+="";
     document.getElementById("div10").innerHTML=fila1;
}
function Usulutan(){
     fila1="";
     fila1+="<table  >";
     fila1+="<tr>";
     fila1+="<td><b>Cabecera departamental</b></td>";
     fila1+="<td><b>Usulutan</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Extencion territorial</b></td>";
     fila1+="<td><b> 2,130km<sup>2</sup></b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td> <b>Fiestas patronales</b></td>";
     fila1+="<td><b>Sel 18 al 25 de noviembre</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Habitantes</b></td>";
     fila1+="<td><b>338,332  habitantes</b></td>";
     fila1+="</tr>";
     fila1+="</table>";
     document.getElementById("div11").innerHTML=fila1;

}
function hacer11(){
     fila1="";
     fila1+="";
     document.getElementById("div11").innerHTML=fila1;
}
function San_Vicente(){
     fila1="";
     fila1+="<table  >";
     fila1+="<tr>";
     fila1+="<td><b>Cabecera departamental</b></td>";
     fila1+="<td><b>San Vicente</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Extencion territorial</b></td>";
     fila1+="<td><b>1184km<sup>2</sup></b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td> <b>Fiestas patronales</b></td>";
     fila1+="<td><b>Del 13 al 31 de diciembre</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Habitantes</b></td>";
     fila1+="<td><b>230,205 habitantes</b></td>";
     fila1+="</tr>";
     fila1+="</table>";
     document.getElementById("div12").innerHTML=fila1;

}
function hacer12(){
     fila1="";
     fila1+="";
     document.getElementById("div12").innerHTML=fila1;
}
function San_Miguel(){
     fila1="";
     fila1+="<table  >";
     fila1+="<tr>";
     fila1+="<td><b>Cabecera departamental</b></td>";
     fila1+="<td><b>San Miguel</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Extencion territorial</b></td>";
     fila1+="<td><b>2,077.1km<sup>2</sup></b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td> <b>Fiestas patronales</b></td>";
     fila1+="<td><b>Del 20 al 30 de junio</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Habitantes</b></td>";
     fila1+="<td><b>520,022 habitantes</b></td>";
     fila1+="</tr>";
     fila1+="</table>";
     document.getElementById("div13").innerHTML=fila1;

}
function hacer13(){
     fila1="";
     fila1+="";
     document.getElementById("div13").innerHTML=fila1;
}
function Morazan(){
     fila1="";
     fila1+="<table  >";
     fila1+="<tr>";
     fila1+="<td><b>Cabecera departamental</b></td>";
     fila1+="<td><b>San Francisco Gotera</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Extencion territorial</b></td>";
     fila1+="<td><b>1,447km<sup>2</sup></b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td> <b>Fiestas patronales</b></td>";
     fila1+="<td><b> Del 1 al 5 de octubre</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Habitantes</b></td>";
     fila1+="<td><b>252 500  habitantes</b></td>";
     fila1+="</tr>";
     fila1+="</table>";
     document.getElementById("div14").innerHTML=fila1;

}
function hacer14(){
     fila1="";
     fila1+="";
     document.getElementById("div14").innerHTML=fila1;
}
function La_Union(){
     fila1="";
     fila1+="<table  >";
     fila1+="<tr>";
     fila1+="<td><b>Cabecera departamental</b></td>";
     fila1+="<td><b>La Union </b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Extencion territorial</b></td>";
     fila1+="<td><b>2,074km<sup>2</sup></b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td> <b>Fiestas patronales</b></td>";
     fila1+="<td><b>4 de noviembre</b></td>";
     fila1+="</tr>";
     fila1+="<tr>";
     fila1+="<td><b> Habitantes</b></td>";
     fila1+="<td><b>372,271 habitantes</b></td>";
     fila1+="</tr>";
     fila1+="</table>";
     document.getElementById("div15").innerHTML=fila1;

}
function hacer15(){
     fila1="";
     fila1+="";
     document.getElementById("div15").innerHTML=fila1;
}
