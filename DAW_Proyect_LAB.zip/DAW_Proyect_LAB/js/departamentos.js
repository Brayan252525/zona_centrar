var Departamentos = {
    "Nombres": [
    {
    "departamento": "Ahuachapan",
    "imagen" : "../img/Ahuchapan.png",
    "habitantes" : "129,750",
    "extencion" : "1,240km",
    "celebridad1" : "Edgardo Alfredo Espino Najarro",
    "img1": "../img/Alfredo_espino.jpg",
    "info1": "Nació en el departamento de Ahuachapán el 8 de enero del año 1900. Su pasión por las letras y el arte fue inculcada desde el seno de su hogar, teniendo como padres al Señor Alfonso Espino y la señora Enriqueta Najarro de Espino, los cuales se desempeñaron ambos como profesores y poetas.",
    "celebridad2" : "Arturo Romero",
    "img2": "../img/Arturo Romero.jpg",
    "info2": "Es uno de los personajes más importantes en el área de la medicina salvadoreña. Tanto así, que se le atribuye ser uno de las personas que fundaron el Colegio de Médico de El Salvador. En honor a esta insigne y ejemplar persona, la cuarta Avenida Sur de Ahuachapán ha sido enaltecida con el nombre de del doctor Arturo Romero.",
    "celebridad3" : "Francisco Menéndez Valdivieso",
    "img3": "../img/Francisco_Menéndez.jpg",
    "info3": "Cuenta la historia que el General Francisco Menéndez Valdivieso nació en la capital del departamento de Ahuachapán un 3 de diciembre de 1830.   Muere en la ciudad de San Salvador un 22 de junio del año de 1890. El mismo se ha inmortalizado en las páginas de la historia de este país por ser un admirable militar y político de El Salvador. Destacando por sobre todas sus hazañas el hecho de haberse desempeñado como presidente de la república en el periodo que abarca los años de 1885 a 1890.",

    },
    {
    "departamento": "Cabañas",
    "imagen" : "../img/Cabañas.png",
    "habitantes" : "149,326",
    "extencion" : "1,240km",
    "celebridad1" : "José Trinidad Cabañas",
    "img1": "../img/Jose_Trinidad_Cabañas.jpg",
    "info1p": "Cuenta la historia que honorable General Cabañas fue compañero de lucha del tan admirado General Francisco Morazán, siendo este último salvado por el hondureño cuando se encontraba en peligro de muerte en la ciudad de San José de Costa Rica el 14 de septiembre de 1842.",
    "info2p": "Una de las grandes hazañas del General José Trinidad Cabañas, fue la de haber asumido la presidencia de Honduras en el año de 1852. Sin embargo, después de una serie de problemas terminó siendo derrocado",
    "info3p": "También, se destacó por haber sido cuñado del General Gerardo Barrios. Sin embargo, una vez que en 1865 se dio la trágica muerte de Barrios, El General José Trinidad Cabañas tuvo que retirarse con la frente en alto hacia Honduras. Allí permaneció, hasta el año 1871 fecha en la cual muere.",
    },
    {
    "departamento": "San Salvador",
    "imagen" : "../img/San_Salvador.png",
    "habitantes" : "2,557,761",
    "historico": "Fundado el 25 de diciembre del año 1889 por la familia de Miguel Molaro Aurora Saint Sauver, apellido éste de origen francés que quiere decir San Salvador.",
    "lm1":"San Salvador (Cabecera departamental)",
    "lm2":"Aguilares",
    "lm3":"Apopa",
    "lm4":"Ayutuxtepeque",
    "lm5":"Cuscatancingo",
    "lm6":"Ciudad Delgado",
    "lm7":"El Paisnal",
    "lm8":"Guazapa",
    "lm9":"Ilopango",
    "lm10":"Mejicanos",
    "lm11":"Panchimalco",
    "lm12":"Nejapa",
    "lm13":"Rosario de Mora",
    "lm14":"San Marcos",
    "lm15":"Santiago Texacuangos",
    "lm16":"Santo Tomás",
    "lm17":"Soyapango",
    "lm18":"Tonacatepeque",
    "extencion" : "886.2 km",
    "ll1":"Sitio arqueológico Cihuatán",
    "ll2":"El Parque Nacional El Boquerón",
    },
    {
    "departamento": "Chalatenango",
    "imagen" : "../img/Chalatenango.png",
    "habitantes" : "274,878 ",
    "historico": "Fundado el 25 de diciembre del año 1889 por la familia de Miguel Molaro Aurora Saint Sauver, apellido éste de origen francés que quiere decir San Salvador.",
    "extencion":"131,05km",
    "informacion":"Su capital o cabecera departamental es Chalatenango, que en idioma Pipil significa 'valle de aguas y arenas' aunque también se puede traducir como 'lugar amurallado de aguas y arenas'",
    "inforh1":"Esta Zona fue habitada durante siglos por tribus Lencas que fueron los primeros en llegar a esas tierras. Pero alrededor del año 1500 fueron invadidos por los Pipiles que eran parte del señorío de Cuzcatlán.",
    "inforh2":"En el año 1807 se le concede a este territorio el rango de villorrio, y su nombre se debe al rey Fernando VII. Ya que el nombre completo de este departamento es San Fernando de Chalatenango.",
    "inforh3":"Se puede acotar que su fundación se produjo en el año 1847, pero se decretó como departamento el día 14 de febrero de 1855, durante el periodo gubernamental del presidente coronel José María San Martín. Este departamento se recuerda tristemente por el asesinato de uno de sus presidentes. Este hecho sucedió en el año 1846, y el presidente víctima del magnicidio fue Francisco Malespín.",
    "celebridad1" : "José María San Martín",
    "img1": "../img/JOSE_MARIA_SAN_MARTIN.jpg",
    "info1": "A este personaje se le debe la fundación de dicho departamento.",
    "celebridad2" : "Andrés Escobar",
    "img2": "../img/andres chalarenango.jfif",
    "info2": "Cantante ganador de un premio de veinticinco mil dólares en un concurso bastante competido.",
    "celebridad3" : "Mario Calero",
    "img3": "../img/mario-calero.jpg",
    "info3": "caricaturista.",
    "celebridad4" : "José Luciano Morales",
    "img4": "../img/Jose_Martin.jfif",
    "info4": "Comandante general de las fuerzas militares en 1876",
    "celebridad5" : "Francisco Martínez Suárez",
    "img5": "../img/Francisco_Martínez.jpg",
    "info5": "Abogado de los Tribunales de La República Este distinguido personaje ocupó varios cargos de importancia como por ejemplo los de diputado, canciller, ministro de relaciones exteriores, ministro de justicia, presidente de la Corte Suprema de justicia, subsecretario de fomento entre otros.",
    "celebridad6" : "Pedro Valle",
    "img6": "../img/Pedro-valle.jpg",
    "info6": "Fue uno de los fundadores del Taller de Letras Gavidia. Se ha desempeñado muchos años como profesor de literatura, habiendo publicado dos poemarios con los nombres de 'Habitante del Alba' en el año 1998 y 'Del deshabitado y otros Poemas' en el año 2005.",
    "celebridad7" : "Refugio Duarte de Romero",
    "img7": "../img/Refugio-duarte.jpg",
    "info7": "Poetisa y escritora salvadoreña.",
    "celebridad8" : "Miguel Plácido Peña",
    "img8": "../img/miguel-placido-pena.jpg",
    "info8": "Poeta.",
    "lm1":"Chalatenango (Cabecera departamental)",
    "lm2":"Municipio Agua Caliente",
    "lm3":"Municipio Arcatao",
    "lm4":"Municipio Azacualpa",
    "lm5":"Municipio Cancasque",
    "lm6":"Municipio Comapala",
    "lm7":"Municipio Citalá",
    "lm8":"Municipio Concepción Quezaltepeque",
    "lm9":"Municipio Dulce Nombre de María",
    "lm10":"Municipio El Carrizal",
    "lm11":"Municipio El Paraíso",
    "lm12":"Municipio La Laguna",
    "lm13":"Municipio La Palma",
    "lm14":"Municipio La Reina",
    "lm15":"Municipio Las Flores",
    "lm16":"Municipio Las Vueltas",
    "lm17":"Municipio Nombre de Jesús",
    "lm18":"Municipio Nueva Concepción",
    "lm19":"Municipio Nueva Trinidad",
    "lm20":"Municipio Ojos de Agua",
    "lm21":"Municipio Potonico",
    "lm22":"Municipio San Antonio de La Cruz",
    "lm23":"Municipio San Antonio Los Rancho",
    "lm24":"Municipio San Fernando",
    "lm25":"Municipio San Francisco Lempa",
    "lm26":"Municipio San Francisco Morazán",
    "lm27":"Municipio San Ignacio",
    "lm28":"Municipio San Luis del Carmen",
    "lm29":"Municipio San Miguel de Mercedes",
    "lm30":"Municipio San Rafael",
    "lm31":"Municipio Santa Rita",
    "lm32":"Municipio Tejutla", 
    "ll1":"Cerro El Pital",
    "ll2":"Río Sumpul en El Salvador",
    },
    {
    "departamento": "La Libertad",
    "imagen" : "../img/La_Libertad.png",
    "habitantes" : "843,500 ",
    "historico": "La fundación de este departamento se ejecutó por el entonces presidente de la República, José María de San Martín con el nombre de Nueva San Salvador, el día 8 de agosto de 1854.   Más adelante sería cambiado por departamento La Libertad.",
    "extencion":"1,653km",
    "celebridad1" : "Francisco Gavidia Guandique",
    "img1": "../img/Francisco_Gavidia.jfif",
    "info1": "Entre los personajes más resaltantes de dentro del campo literario, se encuentran Francisco Gavidia Guandique. Fue insigne escritor que nació en este departamento en el año 1863 y murió en el año 1955. Así mismo, se destacó como politólogo, orador, educador, periodista y traductor.",
    "celebridad2" : "Claudia Lars",
    "img2": "../img/Claudia-Lars.jpg",
    "info2": "Su verdadero nombre fue Margarita del Carmen Brannon.  Fue una gran poetisa y falleció el día 22 de julio de 1974 a la edad de 85 años. Así mismo, también se recuerda a Edgardo Alfredo Espino Najarro, de quien se conservan varias obras poéticas.",
    "celebridad3" : "Vicente Alberto Masferrer Mónico",
    "img3": "../img/Alberto_masferrer.jfif",
    "info3": "Maestro, filósofo y poeta. Murió el día 4 de septiembre del año 1962 a la edad de 64 años, dejando varias obras inconclusas, pero conservadas en la biblioteca nacional de San Salvador.",
    "celebridad4" : "Roque Antonio Dalton García",
    "img4": "../img/Roque_dalton.jpg",
    "info4": "Nació el día 14 de mayo de 1935 y murió el día 10 de mayo de 1975. Esto sucedió a la corta edad de 39 años en la ciudad capital de San Salvador, de donde se le nombró hijo ilustre por ser ésta su ciudad natal. En vida viajó a la Unión Soviética, cosa que explica su marcada tendencia hacia el comunismo.",
    "lm1":"Santa Tecla (Cabecera departamental)",
    "lm2":"Antiguo Cuscatlán",
    "lm3":"Chiltiupán",
    "lm4":"Ciudad Arce",
    "lm5":"Colón",
    "lm6":"Comasagua",
    "lm7":"Huizúcar",
    "lm8":"Jayaque",
    "lm9":"Jicalapa",
    "lm10":"La Libertad ",
    "lm11":"Nuevo Cuscatlán",
    "lm12":"San Juan Opico",
    "lm13":"Quezaltepeque",
    "lm14":"Sacacoyo",
    "lm15":"San José Villanueva",
    "lm16":"San Matías",
    "lm17":"San Pablo Tacachico",
    "lm18":"Talnique",
    "lm19":"Tamanique",
    "lm20":"Teotepeque",
    "lm21":"Tepecoyo",
    "lm22":"Zaragoza",
    "ll1":"Playa Las Flores",
    "ll2":"Playa La Perla",
    "ll3":"Playa Mizata",
    "ll4":"Playa El Zonte",
    "ll5":"Playa El Sunzal",
    "ll6":"Playa El Tunco",
    },
    {
    "departamento": "Cuscatlan",
    "imagen" : "../img/La_Libertad.png",
    "habitantes" : "216,446",
    "historico": "Fue considerada la principal metrópoli de los indios Pipiles precolombinos, fundada en 1504 por el monarca Pipil Topiltzín Acxitl. Desde la antigüedad esta ciudad ha sido célebre por su riquezas y belleza.",
    "historico2": "Cabe destacar que el departamento de Cuscatlán formaba parte del señorío de Cuzcatlán. Una nación Pipil que se extendió por la zona Central y Occidental de lo que hoy se conoce como El Salvador.",
    "extencion":"756km", 
    "celebridad1" : "Hernán “Chuvalo” Cubias",
    "img1": "../img/hernan.jpg",
    "info1": "Todos le conocen como “Chuvalo”. Este atleta se  destacó en el deporte, poniendo muy en alto a su ciudad natal, puesto que alcanzó llegar al Salón de la Fama en la ciudad de New York al ingresar como profesional del boxeo. Actuó en veintiocho peleas, de las cuales, solo perdió tres. En el año 1978 alcanzó el séptimo Ranking como peso ligero a nivel mundial en el campeonato de Centroamérica y El Caribe. Con sus ciento treinta libras ganó varios campeonatos nacionales e internacionales.",
    "celebridad2" : "Rolando Alirio Mena",
    "img2": "../img/rolando.jfif",
    "info2": "Fue un profesional de la locución, quien cursó sus estudios en la escuela José Maximiliano Olano, y en el instituto Walter Thilo Deininger, fue corresponsal de prensa y se hizo merecedor de los premios “La Espiga Dorada” el “Micrófono de oro Nacional” y recibió una placa de La Asamblea Legislativa.",
    "celebridad3" : "Rafael Cabrera",
    "img3": "../img/rafaelcabrera.png",
    "info3": "Este afamado poeta, nació en el departamento de Cuscatlán, en la ciudad de Cojutepeque, y se consagró con su poema “La Ceiba de mi Pueblo”, obra inmortal que lo llevó a recibir varias premiaciones. Su fuente de inspiración, fue Esmeralda. Murió en Guatemala, añorando su pueblo natal a la edad de 66 años.",
    "celebridad4" : "Ana Dolores Arias",
    "img4": "../img/Ana_dolores.jfif",
    "info4": "Aunque su profesión, fue la de educadora, se destacó por sus grandes obras literarias en el género de la poesía, junto a Rafael Cabrera, con su seudónimo de Esmeralda, se les conoce como 'los Novios de Cuscatlán'",
    "celebridad5" : "Antonio Beltrán González",
    "img5": "../img/antonio_beltran.jfif",
    "info5": "Fue un destacado personaje reconocido en el arte de la pirotecnia. Desempeñó varios cargos gubernamentales con gran honestidad y eficacia, apreciado por su pueblo y por su gestión dentro de algunas labores sociales. Se le reconoce como el fundador del Carnaval Enerino, y como buen practicante de la religión católica, perteneció a la Hermandad del Santo Entierro del Sepulcro de La parroquia San Juan.", 
    "celebridad6" : "Julia Díaz",
    "img6": "../img/Julia_dias.jfif",
    "info6": "Famosa por su pincel, destacada por sus hermosas pinturas que han puesto muy en alto a los hijos de Cuscatlán. Fue discípula de Valero Lecha, destacado maestro de la pintura española. Esta valiosa joya de la pintura, fue fundadora de “La Galería de Arte de El Salvador”. Sus obras han sido expuestas en varias y reconocidas galerías de arte en Argentina, Colombia, Venezuela, Estados Unidos, España, Italia y en toda Centroamérica. Antes de morir, recibió la Orden Nacional 'José Matías Delgado'", 
    "celebridad7" : "General Rubén G. Zamora",
    "img7": "../img/Zamora.jfif",
    "info7": "Se desempeñó como director del hospital Rosendo Alvarenga de Cojutepeque durante veintiséis años. Durante toda su carrera como galeno, contribuyó a la formación de muchísimas promociones de médicos y enfermeras, dejando muy en alto se gestión administrativa, y poniendo su conocimiento al servicio de los más necesitados. Fue un médico de gran sensibilidad humana, a quien se le debe el rescate de muchas vidas.",
    "celebridad8" : "General José María Rivas",
    "img8": "../img/Jose_rivas.jfif",
    "info8": "Fue considerado como “Benemérito de la Patria”, reconocido como un pundonoroso militar, muy apegado a la justicia y destacado por su honorabilidad intachable. Su constante espíritu de superación, lo llevó a asumir muchos compromisos con su patria, saliendo siempre airoso en todas las actividades que como militar emprendió. Excelente esposo, amante y padre de familia. Fue un mujeriego empedernido.", 
    "lm1":"Cojutepeque (Cabecera departamental)",
    "lm2":"Candelaria",
    "lm3":"El Rosario",
    "lm4":"Monte San Juan",
    "lm5":"Oratorio de Concepción",
    "lm6":"San Bartolomé Perulapía",
    "lm7":"San Cristóbal",
    "lm8":"San José Guayabal",
    "lm9":"San Pedro Perulapán",
    "lm10":"San Rafael Cedros",
    "lm11":"San Ramón",
    "lm12":"Santa Cruz Analquito",
    "lm13":"Santa Cruz Mi Chapa",
    "lm14":"Suchitoto",
    "lm15":"Tenancingo",
    "lm16":"El Carmen",

    "ll1":"El Cerro de las Pavas",
    "ll2":"Volcán Chichontepec",
    "ll3":"El Cerro la Colima",
    "ll4":"La ciudad de Suchitoto",
    "ll5":"La Peña Herrera",
    "ll6":"Río Jiboa en El Salvador",

}


    ]
    };
    //Obteniendo el elemento contenedor donde se cargarán
    //todos los datos del objeto JSON
    var div = document.getElementById("imagen");
    div.innerHTML = volcarDatos(Departamentos.Nombres);
    function volcarDatos(datos){
    var total = datos.length;
    data = "";
    for(var i=0; i<total; i++){
        if (datos[i].departamento = "Ahuachapan") {
            data += "<img src=" + datos[i].imagen + " alt='Card image cap'>";
        }else if (datos[i].departamento = "Cabañas") {
            data += "<img src=" + datos[i].imagen + " alt='Card image cap'>";
        }
    }
    return data;
    }

    
    var div1 = document.getElementById("habitantes");
    div1.innerHTML = volcarDatos1(Departamentos.Nombres);
    function volcarDatos1(datos1){
    var total = datos1.length;
    data1 = "";
    for(var i=0; i<total; i++){
        if (datos1[i].departamento = "Ahuachapan") {
            data1 += datos1[i].habitantes;
        }
    }
    return data1;
    }

    var div2 = document.getElementById("extencion");
    div2.innerHTML = volcarDatos2(Departamentos.Nombres);
    function volcarDatos2(datos2){
    var total = datos2.length;
    data2 = "";
    for(var i=0; i<total; i++){
        if (datos2[i].departamento = "Ahuachapan") {
            data2 += datos2[i].extencion+"<sup>2</sup>";
        }
    }
    return data2;
    }

    var div2 = document.getElementById("extencion");
    div2.innerHTML = volcarDatos2(Departamentos.Nombres);
    function volcarDatos2(datos2){
    var total = datos2.length;
    data2 = "";
    for(var i=0; i<total; i++){
        if (datos2[i].departamento = "Ahuachapan") {
            data2 += datos2[i].extencion+"<sup>2</sup>";
        }
    }
    return data2;
    }

    var div3 = document.getElementById("");
    div3.innerHTML = volcarDatos3(Departamentos.Nombres);
    function volcarDatos3(datos3){
    var total = datos3.length;
    data3 = "";
    for(var i=0; i<total; i++){
        if (datos3[i].departamento = "Ahuachapan") {
            data3 += datos3[i].extencion+"<sup>2</sup>";
        }
    }
    return data3;
    }

    var div4 = document.getElementById("extencion");
    div4.innerHTML = volcarDatos4(Departamentos.Nombres);
    function volcarDatos4(datos4){
    var total = datos4.length;
    data4 = "";
    for(var i=0; i<total; i++){
        if (datos4[i].departamento = "Ahuachapan") {
            data4 += datos4[i].extencion+"<sup>2</sup>";
        }
    }
    return data4;
    }